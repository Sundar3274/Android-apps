package com.example.shar;

import android.content.SharedPreferences;
import android.os.Bundle;

import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private TextView textView;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);

// Check if a value with key "message" exists
        if (sharedPreferences.contains("message")) {
            // If it exists, retrieve the value and display it
            String message = sharedPreferences.getString("message", "");
            textView.setText(message);
        } else {
            // If it doesn't exist, set a default value
            textView.setText("No message stored");
        }

        // Save a value to SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("message", "ANDROID-APP-II");
        editor.apply();
    }
}