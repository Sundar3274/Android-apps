package com.example.shar;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button butActivity2 = findViewById(R.id.btnActivity1);
        butActivity2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ActivIntent = new
                        Intent(MainActivity.this, MainActivity2.class);
                startActivity(ActivIntent);
            }
        });
    }
}